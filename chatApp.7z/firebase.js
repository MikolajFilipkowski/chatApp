import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
    apiKey: "AIzaSyApjuU3vFK2Lojw6cJRXwp6SHj6QCaxpH0",
    authDomain: "chatapp-cc5c8.firebaseapp.com",
    projectId: "chatapp-cc5c8",
    storageBucket: "chatapp-cc5c8.appspot.com",
    messagingSenderId: "697200761177",
    appId: "1:697200761177:web:a9bf3e2c6b8937b4ced448",
    measurementId: "G-Z8M0XQ5KZB"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);