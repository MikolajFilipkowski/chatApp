import { View, Text } from "react-native";

export default function ChatScreen() {
  return (
    <View>
        <Text>Chat</Text>
    </View>
  )
}
