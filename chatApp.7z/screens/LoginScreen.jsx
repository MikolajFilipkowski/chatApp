import { Text, View, TextInput, Button } from 'react-native'
import { useState } from 'react'

export default function LoginScreen() {
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")

    function sendFormHandler(e) {
        console.log(email)
        console.log(password)

        setEmail("")
        setPassword("")
    }

    return (
        <View>
            <Text>Email</Text>
            <TextInput onChange={(e) => setEmail(e.target.value)} value={email}/>
            <Text>Password</Text>
            <TextInput onChange={(e) => setPassword(e.target.value)} value={password} secureTextEntry={true}/>
            <Button onPress={sendFormHandler} title="Log In"/>
        </View>
    )
}
