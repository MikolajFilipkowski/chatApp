import { useState } from 'react'
import { Text, View, Button, TextInput } from 'react-native'

export default function SigninScreen() {
    const [username, setUsername] = useState("")
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")

    function sendFormHandler(e) {
        console.log(username)
        console.log(email)
        console.log(password)

        auth()
        .createUserWithEmailAndPassword(email, password)
        .then(() => {
            console.log('User account created & signed in!');
        })
        .catch(error => {
            if (error.code === 'auth/email-already-in-use') {
            console.log('That email address is already in use!');
            }

            if (error.code === 'auth/invalid-email') {
            console.log('That email address is invalid!');
            }

            console.error(error);
        });

        setUsername("")
        setEmail("")
        setPassword("")
    }

    return (
        <View>
            <Text>Username</Text>
            <TextInput onChange={(e) => setUsername(e.target.value)} value={username}/>
            <Text>Email</Text>
            <TextInput onChange={(e) => setEmail(e.target.value)} value={email}/>
            <Text>Password</Text>
            <TextInput onChange={(e) => setPassword(e.target.value)} value={password} secureTextEntry={true}/>
            <Button onPress={sendFormHandler} title="Sign In"/>
        </View>
    )
}
