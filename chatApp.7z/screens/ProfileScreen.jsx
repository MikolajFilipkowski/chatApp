import { View, Text } from "react-native";

export default function ProfileScreen() {
  return (
    <View>
        <Text>Profil</Text>
    </View>
  )
}
