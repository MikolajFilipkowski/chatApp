import { View, Text } from "react-native";

export default function SettingsScreen() {
  return (
    <View>
        <Text>Settings</Text>
    </View>
  )
}
